package com.example.n01202455.cardview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class bhej_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bhej_item);
    }
}
